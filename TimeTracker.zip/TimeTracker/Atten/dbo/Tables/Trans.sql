CREATE TABLE [dbo].[Trans] (
    [EmpID]    VARCHAR (50) NULL,
    [empname]  VARCHAR (50) NULL,
    [sitecode] VARCHAR (10) NULL,
    [CardID]   VARCHAR (10) NULL,
    [dt]       DATETIME     NULL,
    [InOut]    VARCHAR (10) NULL,
    [LocCode]  VARCHAR (5)  NULL
);

